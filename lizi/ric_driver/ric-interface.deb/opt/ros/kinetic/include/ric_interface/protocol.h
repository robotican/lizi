/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

namespace ric
{
    namespace protocol
    {
        const uint16_t MAX_PKG_SIZE = 512;
        const uint8_t HEADER_SIZE = 2;
        const uint8_t CHKSUM_SIZE = 1;
        const uint8_t HEADER_CODE = 200;
        const uint8_t HEADER_INDX = 0;
        const uint8_t PAYLOAD_SIZE_INDX = 1;

        // message type
        // 100-199 - sensors / actuators
        // 200-250 - protocol messages
        enum class Type
        {
            LOCATION = 100, // i.e. : GPS sensor
            ORIENTATION = 101, // i.e. : IMU sensor
            ENCODER = 102,
            SERVO = 103,
            TOGGLE = 104, // i.e. : Eswitch, toggle, button
            PROXIMITY = 105, // i.e. : TOF LIDAR, URF
            BATTERY = 106,

            KEEP_ALIVE = 248,
            LOGGER = 249,
            ERROR = 250
        };

        // PACKAGE
        struct package
        {
            uint8_t type = 0;
            uint8_t id = 0;
        };

        // KEEPALIVE
        struct keepalive : package
        {
            keepalive() { type = (uint8_t)Type::KEEP_ALIVE; }
        };

        // LOGGER
        struct logger : package
        {
            enum Sevirity
            {
                INFO = 0,
                WARN = 1,
                CRITICAL = 2
            };

            logger() { type = (uint8_t)Type::LOGGER; }
            char msg[30];
            uint8_t sevirity = 0;
        };

        // ERROR
        struct error : package
        {
            uint8_t code = 0; //error code
            uint8_t comp_type = 0; //reporting component type
            uint8_t comp_id = 0; //reporting component id
            error() { type = (uint8_t)Type::ERROR; }
        };

        // ORIENTATION
        struct orientation : package
        {
            orientation() { type = (uint8_t)Type::ORIENTATION; }
            float 	roll = 0,
                    pitch = 0,
                    yaw = 0,
                    accl_x = 0,
                    accl_y = 0,
                    accl_z = 0,
                    gyro_x = 0,
                    gyro_y = 0,
                    gyro_z = 0,
                    mag_x = 0,
                    mag_y = 0,
                    mag_z = 0;
        };

        struct toggle : package
        {
            toggle() { type = (uint8_t)Type::TOGGLE; }
            uint8_t on = 0; // true / false
        };

        // LOCATION
        struct location : package
        {
            location() { type = (uint8_t)Type::LOCATION; }
            double lat = 0, lon = 0;
            float alt = 0;
            float speed = 0;
            float heading = 0;
            uint8_t satellites = 0;
            uint8_t date_time = 0; //UTC hundredths of a second
        };

        // PROXIMITY
        struct proximity : package
        {
            proximity() { type = (uint8_t)Type::PROXIMITY; }
            uint16_t value = 0; //distance in millimers
        };

        // ENCODER
        struct encoder : package
        {
            encoder() { type = (uint8_t)Type::ENCODER; }
            int64_t ticks = 0; // number of ticks can be positive or negative
        };

        // SERVO
        struct servo : package
        {
            servo() { type = (uint8_t)Type::SERVO; }
            uint16_t value = 0;
        };

        struct battery : package
        {
            battery() { type = (uint8_t)Type::BATTERY; }
            uint16_t value = 0; //millivolt
        };


    }
}



#endif //PROTOCOL_H