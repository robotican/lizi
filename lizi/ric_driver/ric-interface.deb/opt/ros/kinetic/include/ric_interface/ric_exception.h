/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */

#ifndef RIC_INTERFACE_RIC_EXCEPTION_H
#define RIC_INTERFACE_RIC_EXCEPTION_H

#include <iostream>

namespace ric
{
    struct RicException : public std::runtime_error
    {
    public:
        RicException(std::string msg) : std::runtime_error(msg) {}
    };

    struct ConnectionExeption : public RicException
    {
    public:
        ConnectionExeption(std::string msg) : RicException(msg) {}
    };
}


#endif //RIC_INTERFACE_RIC_EXCEPTION_H
