/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */


#ifndef RIC_INTERFACE_BOARD_MANAGER_H
#define RIC_INTERFACE_BOARD_MANAGER_H

#include "communicator.h"
#include "timer.h"
#include "protocol.h"
#include "ric_observer.h"
#include <vector>
#include <list>
#include <math.h>
#include <string.h>
#include <iostream>

namespace ric
{
    class RicInterface
    {
    private:
        const int SEND_KA_TIMEOUT = 300; //ms
        const int GET_KA_TIMEOUT = 1500; //ms

        bool is_board_alive_ = true, got_keepalive_ = false;
        Timer send_keepalive_timer_, get_keepalive_timer_;
        Communicator comm_;
        byte pkg_buff_[protocol::MAX_PKG_SIZE];

        void readAndHandlePkg();
        void checkKeepAliveFromRic();
        void sendKeepAlive();
        void clearBuffer();

        std::vector<RicObserver*> subs_list_;


    public:
        RicInterface();
        void connect(std::string port);
        void loop();
        bool isBoardAlive() { return is_board_alive_; }
        void writeCmd(const protocol::package &pkg, size_t size);
        void attach(RicObserver* observer);
        void deattach(RicObserver* observer);
        void notify(const protocol::package& ric_package);
        static std::string compType2String(const protocol::Type comp_type);
    };
}



#endif //RIC_INTERFACE_BOARD_MANAGER_H
